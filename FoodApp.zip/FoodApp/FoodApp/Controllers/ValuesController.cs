﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace FoodApp.Controllers
{
    public class ValuesController : ApiController
    {
        // GET api/values
        public HttpResponseMessage Get()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("Name");
            dt.Columns.Add("Address");
            dt.Columns.Add("Email");
            dt.Columns.Add("Phno");
            dt.Columns.Add("image_url");
            dt.Columns.Add("rating");

            dt.Rows.Add("Madras Kitchen Company", "154 1st Floor Velachery Main Road, Chennai (Madras) 600042 India", "mkc@gmail.com", "9627232442", "https://media-cdn.tripadvisor.com/media/photo-s/18/e1/91/69/vada-pav-mumbai-street.jpg","3.6");
         

            return Request.CreateResponse(HttpStatusCode.OK, dt);
        }

        // GET api/values/5
        public string Get(int id)
        {
            return "value";
        }

        // POST api/values
        public void Post([FromBody] string value)
        {
        }

        // PUT api/values/5
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/values/5
        public void Delete(int id)
        {
        }
    }
}
