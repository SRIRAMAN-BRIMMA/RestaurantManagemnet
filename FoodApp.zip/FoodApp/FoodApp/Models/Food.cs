﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FoodApp.Models
{
    public class Food
    {
        public int Id { get; set; }
        public string name { get; set; }   
        public string address { get; set; }
        public string image_url { get; set; }
        public string email { get; set; }
        public string phoneno { get; set; }
        public string rating { get; set; }
            
        
    }
}